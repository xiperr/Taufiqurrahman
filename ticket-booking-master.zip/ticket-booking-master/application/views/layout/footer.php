<div class="row bg-purple-darken font-white" id="footer">
    <div class="section">
        <div class="col-md-5">
            <h2 class="font-bold font-lg">Alamat</h2>
            <section class="line"></section>
            <p class="font-sm font-medium"><i class="fa fa-map-marker"></i> Jalan Johar No.14, Surabaya</p>
            <p class="font-sm font-medium"><i class="fa fa-phone"></i> (031) 70120731</p>
            <p class="font-sm font-medium"><i class="fa fa-whatsapp"></i> 082 143463188</p>
        </div>
        <div class="col-md-7 txt-right">
            <h2 class="font-bold font-lg pb-3">Kunjungi Kami</h2>
            <a href="#" class="follow hvr-rectangle-out"><i class="fa fa-instagram fa-2x"></i></a>
            <a href="#" class="follow hvr-rectangle-out"><i class="fa fa-facebook fa-2x"></i></a>
            <a href="#" class="follow hvr-rectangle-out"><i class="fa fa-twitter fa-2x"></i></a>
            <a href="#" class="follow hvr-rectangle-out"><i class="fa fa-google-plus fa-2x"></i></a>
        </div>
        <div class="col-md-12 text-center">
            <hr>
        </div>
        <div class="col-md-6">
            <b>Copyright &copy; Reni Jaya Travel</b>
        </div>
        <div class="col-md-6 text-right">
            <b>Created by <a href="#"><u>Anang Novriadi and Team</u></a></i></b>
        </div>
    </div>
</div>