<script type="text/javascript" src="<?php echo base_url('assets/front/js/jquery.js'); ?>"></script>
<!-- <script type="text/javascript" src="<?php echo base_url('assets/front/js/bootstrap.min.js'); ?>"></script> -->
<script type="text/javascript" src="<?php echo base_url('assets/front/js/global.js'); ?>"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>