<link rel="icon" href="assets/images/favicon.png">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/css/style.css'); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/css/responsive.css'); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/css/bootstrap.min.css'); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/css/font-awesome.min.css'); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/css/hover.css'); ?>">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">