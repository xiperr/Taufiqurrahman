# ticket-booking
Pemesanan Tiket Pesawat dan Kapal Online Di CV.Reni Jaya Travel

### How to use

```
jalankan xampp
import database -> reni_jaya_fresh.sql
admin dashboard: masuk ke folder admin -> application -> config -> config.php -> pada $config['base_url'], sesuaikan dengan penempatan folder anda
halaman pemesanan(front-end): masuk ke folder application -> config -> config.php -> pada $config['base_url'], sesuaikan dengan penempatan folder anda
buka localhost yang sudah anda sesuaikan pada base url
```

```
NB: jalankan kedua pada browser yang berbeda(contoh: admin dashboard -> chrome, dan halaman pemesanan(front-end) -> firefox), jika dijalankan dalam satu browser akan terjadi bentrok pada session
```
