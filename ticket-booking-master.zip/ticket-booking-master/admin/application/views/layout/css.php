<link rel="stylesheet" href="<?php echo base_url('assets/admin/bootstrap/css/bootstrap.min.css'); ?>" />
<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet" />
<link rel="stylesheet" href="<?php echo base_url('assets/admin/css/style.css'); ?>" />
<link rel="stylesheet" href="<?php echo base_url('assets/admin/et-line-font/et-line-font.css'); ?>" />
<link rel="stylesheet" href="<?php echo base_url('assets/admin/font-awesome/css/font-awesome.min.css'); ?>" />
<link type="text/css" rel="stylesheet" href="<?php echo base_url('assets/admin/weather/weather-icons.min.css'); ?>" />
<link type="text/css" rel="stylesheet" href="<?php echo base_url('assets/admin/weather/weather-icons-wind.min.css'); ?>" />