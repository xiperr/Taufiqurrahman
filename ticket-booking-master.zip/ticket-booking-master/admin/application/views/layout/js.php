<!-- jQuery --> 
<script src="<?php echo base_url('assets/admin/js/jquery.min.js'); ?>"></script> 
<script src="<?php echo base_url('assets/admin/bootstrap/js/bootstrap.min.js'); ?>"></script> 
<script src="<?php echo base_url('assets/admin/js/ovio.js'); ?>"></script> 

<!-- charts --> 
<script src="<?php echo base_url('assets/admin/plugins/charts/code/modules/exporting.js'); ?>"></script> 
<script src="<?php echo base_url('assets/admin/plugins/charts/chart-functions.js'); ?>"></script>
<script src="<?php echo base_url('assets/admin/plugins/charts/code/highcharts.js'); ?>"></script>