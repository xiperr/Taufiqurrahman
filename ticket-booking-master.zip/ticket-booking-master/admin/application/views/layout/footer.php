<footer class="main-footer dark-bg">
    <div class="pull-right hidden-xs"></div>
    Copyright &copy; 2018 | CV. Reni Jaya Travel 
</footer>